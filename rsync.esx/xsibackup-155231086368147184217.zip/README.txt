(c) XSIBACKUP-FREE for ESXi Hypervisor 5.1/5.5/6.0/6.5/6.7

GENERAL CONSIDERATIONS:
	
	ATTENTION: if you have your .vmdk disks spread across different 
	data stores, XSIBackup software might overwrite disks, as it copies 
	every .vmdk disk to the same backup folder. If this is your case, 
	you should rename the disks so that they are unique. 

MANUAL INSTALLATION/ UPGRADE PROCEDURE:

	- Copy main package file to /tmp, cd /tmp

		unzip *.zip	

	- Run: 
	
		chmod 0700 install && ./install

	- If you have a previous installation, rename the xsi-dir folder to
	serve as a backup and run the installer. The installation process will 
	copy your keys, licenses and configuration files to /tmp and will try 
	to restore them once finished, but that's not a persistent path in ESXi.
	
	- Once you have finished installing the new version, please remove the 
	backup folder, it could mislead XSIBackup when executing remote commands.

	- The installation script will ask you to provide a base installation 
	path and it will add the xsi-dir on top of that base path.

	- Read the ManPage at https://33hops.com/xsibackup-help-man-page.html




	
	
	
