MANUAL INSTALLATION PROCEDURE ESXi Hypervisor 5.1/5.5/6.0/6.5

- Extract to the desired path (default recommended: /vmfs/volumes/datastore1/xsi-dir). 
ATTENTION: copy all files and folders inside the XSIBACKUP-PRO package to the install dir, they are all part of the program

- If you have a previous installation (Free or Pro), remove all files but the RSA Key pair (xsibackup_id_rsa & xsibackup_id_rsa.pub) and the xsibackup-cron file (in case you want to keep your scheduled jobs), then unzip the contents of this file there. If you keep all paths the same you don't need to reinstall cron.

- If this is your first installation, choose a persistent path to install XSIBACKUP-PRO. If you are not 100% sure that the path you want to install is persistent, use the recommended installation path: /vmfs/volumes/datastore1/xsi-dir

- Assign execute permissions to the xsibackup file and the bin directory.

	youresxi# cd /vmfs/volumes/datastore1/xsi-dir
	youresxi# chmod -R 0700 xsibackup EULA bin conf

- Read the ManPage at https://33hops.com/xsibackup-help-man-page.html
